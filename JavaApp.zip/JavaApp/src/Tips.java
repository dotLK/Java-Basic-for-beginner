
public class Tips {

    public static void main(String[] args) {
       
      /* for(int i =0; i<=20 ;i++){
           
         if(i % 2 ==0 ){ //%
             // even numbers
             System.out.println(i);
         
         }else{
             //odd numbers
             System.out.println(i);
         }            
           
       } 
     // a-z 
      
     for(int i =0; i < 26; i++){     
         System.out.println((char)('A'+i));     
     } 
      
     */
      
/*  00000
    00000
    00000
    00000
    00000  */
  /*  
    int y = 0;

    while(y<5){ 
        int x = 0;
        while( x <5 ){        
            System.out.print("0");
            x++;
        }        
        System.out.print(" ");
        y++;
    }  
     */ 
    
/*
  0
  00
  000
  0000   
 */

int y = 0;

    while(y<10){ // main

          int x =0;
        // start
        while(x <= y){            
            
          System.out.print("*");            
          
        x++;
        } //end     
        
       
     y++;
        System.out.println();
    } // end main
    
    
    
    
    
    
    
    

//Multliplication Table   
/*
for(int y= 1; y<13 ; y++){

    for(int x = 1; x<13 ; x++){
    
        
        int z = x* y ; 
        // 1 *1 
        // 1 *2
       System.out.print(z +" |"); 
    
    }

   System.out.println();
}

*/




    }  
}
