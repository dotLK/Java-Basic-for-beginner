
public class FlowControl2 {

    
    public static void main(String[] args) {
       
    /*  int a = 3 ;
       
       // Nested if Statements
       if(a<10 ){ // true  a <10  a> 5       
           
           if(a > 5){ // true                
                System.out.println("value is valid...");
                
           }else{               
               System.out.println("A less than 5");
           }          
           
       }else{  // false      
           
       System.out.println("A greater than 10");
       
       }
   
     */  
       
  /*    
   int b  = 39;
   
   if( b >= 1 && b <= 10  ){ 
       
       System.out.println("A = 1 - 10"); 
       
   }
   else if(b >= 20 && b <= 29 ){ //  22
   
        System.out.println("A =  20- 29 ");
   }
   else if(b >= 30 && b <= 39 ){
   
        System.out.println("A = 30- 39");
   }
   else if(b >= 40 && b >= 49 ){
   
        System.out.println("A = 40-49");
   }
   
   else{
   
       System.out.println("A greater than 49");
   }
       
  
   */
  /*
  int q = 3;
  String lng = null ;
  
  switch(q){
      
      case 1 : lng = "sinhala" ; break;
      
      case 2 : lng = "tamil" ; break;
      
      case 3 : lng = " english" ; break;
      
      default : lng = "Not valid" ;
        
  }

  System.out.println(lng); 
  */
   
   /*
  
  1.sinhala
  2.tamil 
  3.english
  
  */
  /* 
 String text = "EnGLisH" ; 
 
 String input  = null ;
 
 switch(  text.toUpperCase()){
 
     case "SINHALA" : input = "Sinhala" ;  break;
     
     case "english" : input = "English" ;  break;
     
     
     default : input = "Not valid" ;
     
     
     
 }
        System.out.println(input); */
 String text = "EnGLisH" ; 
 
 String input  = null ;
 
 switch(  text.toUpperCase()){
 
     case "SINHALA" : input = "Sinhala" ;  break;
     
     case "english" : input = "English" ;  break;
     
     
     default : input = "Not valid" ;
     
     
     
 }
        System.out.println(input);

 
   
   
        
    }
    
}
