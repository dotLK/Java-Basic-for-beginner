
package GUI.z;

import java.awt.Graphics;

public class paintme {

    public static void main(String[] args) {
       
        paintme pp = new paintme();
    }
    
    public void paintit(Graphics g){
     
        g.fillOval(10, 10, 10, 10);
        
       
    
    }
}
