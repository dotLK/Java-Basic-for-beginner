package myPack;


public class Man {

    
    
    
    public  String name ;
    public  int age ;
    
    
    public Man(String n , int b){
    
    name = n ;
    age = b ;
    
    
    }
} 
//   
//    
///**
// * 
// * @param name  "Saman"
// */
//  public void talk(String name){
//  
//      System.out.println( name + " is  talking");
//  
//  }
// 
//  /**
//   * 
//   * @param name  Ex ." kamal"
//   * @param food  Ex . " Rice" 
//   */
//  public void eat(String name, String food){
//  
//  
//      System.out.println(name + " is eating " + food);
//  
//  }
//  
//  /**
//   * 
//   * @param i = int = ex  5
//   * @param x = int = ex  6 
//   * @return   = return  = i * x 
//   */
//  
//  public int cal(int i , int x){
//  
//   int z =   i * x  ;
//   
//   return z ;
//   
//  }
//  
//  public String plus(String a , String b){
//  
//   String s = a +b ;
//   
//   
//   return s ;
//   
//  }
//  
//  
//  private String name ;
//  
// public void setname(String nm){
// 
//  name = nm ;
//  
// } 
// public void hi(){
// 
//     System.out.println("Hi " + name );
// 
// 
//         
         
         
 

