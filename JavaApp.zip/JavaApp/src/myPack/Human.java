package myPack;

import Javalk.Divisions;



/**
 *
 * @author Go
 */
public class Human {


    public static void main(String[] args) {
      
        System.out.println(Divisions.ProvinceCount());   
        
        
   //Man m1 = new Man();   
  // m1.eat("Amara", "cake");
   //m1.talk("Amara");
   
   
  // Man m2 = new Man();
  // m2.eat("jhon", "bun");
  
   
  //Man mm = new Man();
  
  //int ans =  mm.cal(4, 2);
  
      
 // System.out.println(ans);
  
 //Man m3 = new Man(); 
 //String  as =  m3.plus("iam ", "lk");
  
        //System.out.println(as);
  
        
 // Man me = new Man();
  
  //me.setname("nimal");
 // me.hi();
        
        
  
 Man m10 = new Man("saman", 25) ;
 
        System.out.println( m10.age +" "+ m10.name);
      
  Man m11 = new Man("Kamal", 22) ;
  
   System.out.println( m11.age+" " + m11.name);
        
    }
    
}
