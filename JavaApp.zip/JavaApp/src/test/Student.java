package test;

import java.io.Serializable ;


public class Student implements Serializable{
    
    /**
     * ළෙ
     * "SMSAs"
     */ 
    public String Name ;
    public int age ;

    public Student(int i, String baby) {
        
    }
    
    
}
