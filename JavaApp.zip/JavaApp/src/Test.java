
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;
import callab.CalLab;


public class Test {

   
    public static void main(String[] args) {
       
    /*    

        //1
        
        Scanner inp = new Scanner(System.in);
        String n = inp.nextLine();
        System.out.println(n);
   
      /*  
        Scanner input =  new Scanner(System.in);
        int bo = input.nextInt();
        System.out.println(bo);
        
     //2
     
        try {  
        // Userr errors  bad inputs
        // programer errors  bugs in program
            
        } catch (Exception e) {
        }
     
 */   
      //3
        double  a =0.0;        
        a = Math.log(15);
        //area =  Math.PI * 7 ; //  2^pi *r // 
       // circ = 2 * Math.PI * 7 *7; //  2^pi *r2 // 
        a = Math.max(45, 65);
        a = Math.min(1, 8);
        a = Math.round(5.12);
        a = Math.sqrt(12);
        a = Math.pow(2, 3);
        a = Math.abs(-45.12);
        a = Math.round(12.574);
        
        System.out.println(a);
  /*      
    
//4 
        ArrayList<Integer>  name = new ArrayList<>();
        name.add(10);
        name.add(20);
        name.add(30);
        
        name.remove(1);
        name.clear();        
        System.out.println(name.size());
        
        int fon = 1;
        
        Random gen = new Random();
        int ii = gen.nextInt(9); //9 adu
        System.out.println("Random Num :" + ii);
        
        
        for (int i = 0; i < 10; i++) {
            name.add(gen.nextInt(100)+1);
        }
        
       
        
        
        

//* */
    /*  
      Calendar cal = Calendar.getInstance();
        int date = cal.get(Calendar.DATE);
        int month = cal.get(Calendar.MONTH);
        int year = cal.get(Calendar.YEAR);
        System.out.println(date+"_"+month+"_"+year); 
      
       Date dd =new Date();
        System.out.println(dd.getMonth());
        
  
        // file io  txt.text
        
 
      
        System.out.println(CalLab.cal(5, 5));  
     
      
      
    }
     
}
*/
    } }