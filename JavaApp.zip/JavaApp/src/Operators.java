
public class Operators {

    
    public static void main(String[] args) {
    
     int i = 5;
     
     
        System.out.println(i--); //i print b4  Postfix operators
        System.out.println(i);
        System.out.println(--i); // prefix operators i after print
       
// Arithmetic Operators: *, /, %, +, -

    double fn = 46 ;
    double sn = 5 ;
    
    double tot = fn / sn ;
   
    
    
     System.out.println(tot);     
            
      
     fn = fn + 8;
     
     
     
     System.out.println(fn);     
     
      fn += 8 ;
      
     System.out.println(fn);     
     
     
      
    }
    
}
