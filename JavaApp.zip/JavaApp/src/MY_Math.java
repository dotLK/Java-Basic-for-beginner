
import java.util.Random;


public class MY_Math {

    public static void main(String[] args) {
       
    // r  = 7 
    
    double a = 0;
    
    a =  Math.PI * 7 * 7 ;
        System.out.println(a);
        
    double b = -12.57;
    
    System.out.println(Math.abs(b));
    
    System.out.println(Math.ceil(b));
    
    System.out.println(Math.floor(b));
    
    System.out.println(Math.log(15));
    
    System.out.println(Math.max(45.12, 23.54));
    
    System.out.println(Math.min(45.12, 23.54));
    
    System.out.println(Math.pow(2, 15));
    
    System.out.println(Math.round(12.412));
    
    System.out.println(Math.sqrt(100));
    
    System.out.println(Math.random());
    


    
        Random rn  = new Random();
        
    
        
    }
    
}
