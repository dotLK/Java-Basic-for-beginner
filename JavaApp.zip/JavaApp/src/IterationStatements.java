
public class IterationStatements {

    
    public static void main(String[] args) {
       
   /*    
        int i= 0 ;
        
        while(i<=100){
        
            System.out.println( " i ="  + i);
       
         i += 5; // i = i +10 ;
           
        }
     
     
    int a = 1 ;
    
    do{
        System.out.println("a = " + a ); 
        a++ ; // a =a +1 
        
    }while(a <=5 );
   */
   
  
/*
   for(int i= 0 ; i < 24; i+=2 ){ // i+=2 i = i+ 2
        // -10  -1 0 1+
        
       System.out.println(i);
       
   }  
    */
 
int i = 50;
 while(i > 0){
     System.out.print(i + " ");
     
     if((i%5)==0 ){
         System.out.println();
     
     }
     
 i--;
 }
 



    }
    
}
