
public class Stu {
    
    private  String _Name ;
    private  int _Age ;
    
  
    public  Stu(String name ,int age){
    
     this._Name = name ;
     
     this._Age = age ;
     
        }
    
    public String Name(){
    
    return  this._Name ;
    
    }
    
    
    public int Age(){
    
    return  this._Age ;
    
    }
    
    
    
    
}
